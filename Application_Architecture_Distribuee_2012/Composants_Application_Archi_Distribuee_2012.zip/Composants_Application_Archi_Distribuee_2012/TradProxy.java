
public class TradProxy {

	public static String translateFrToEn(String phrase) {
		String res = "";
		
		for (int i = phrase.length()-1; i >= 0; i--) {
			res += phrase.charAt(i);
		}
		
		return res;
	}

}
