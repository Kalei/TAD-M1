
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		short[] signal = Toolbox.recordMic(15);
		System.out.print("Toolbox.recordMic(): [");
		for (int i=0; i<signal.length; i++) {
			System.out.print(String.valueOf(signal[i])+",");
		}
		System.out.println("]");
		
		String decoded = SpeerProxy.decode(signal);
		System.out.println("SpeerProxy.decode(): "+decoded);

		String translated = TradProxy.translateFrToEn(decoded);
		System.out.println("TradProxy.translateFrToEn(): "+translated);

		short[] translatedSignal = TTSProxy.synthesizeEn(translated);
		System.out.print("TTSProxy.synthesizeEn(): [");
		for (int i=0; i<translatedSignal.length; i++) {
			System.out.print(String.valueOf(translatedSignal[i])+",");
		}
		System.out.println("]");

		System.out.print("Toolbox.playSignal() : ");
		System.out.println(Toolbox.playSignal(translatedSignal));
		
		
	}

}
