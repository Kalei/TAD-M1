
public class Toolbox {
	
	public static short[] recordMic(int length) {
		short[] res = new short[length];
		
		for (int i = 0; i < length; i++) {
			res[i] = (short)(i % 10);
		}
		
		return res;
	}
	
	public static String playSignal(short[] signal) {
		short prev = -1;
		
		for (int i = 0; i < signal.length; i++) {
			if (prev > 0 && prev != signal[i]+1) {
				return "Play Error: the given signal is not the translated version of what recordMic produced!";
			}
			prev = signal[i];
		}
		
		return "Play successful!";
	}

}
