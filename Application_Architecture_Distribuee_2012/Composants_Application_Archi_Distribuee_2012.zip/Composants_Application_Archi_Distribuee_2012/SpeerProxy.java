
public class SpeerProxy {

	public static String decode(short[] audio) {
		String res = "";
		
		for (int i = 0 ; i < audio.length ; i++) {
			res += String.valueOf(audio[i])+",";
		}
		
		if (res.length() > 0) {
			res = res.substring(0, res.length()-1);
		}
		
		return res;
	}
	
}
