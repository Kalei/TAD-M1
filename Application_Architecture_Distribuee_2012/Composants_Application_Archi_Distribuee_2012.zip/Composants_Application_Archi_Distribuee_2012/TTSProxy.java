
public class TTSProxy {
	
	public static short[] synthesizeEn(String sentence) {
		String[] parts = sentence.split(",");
		
		short[] res = new short[parts.length];
		
		for (int i = 0; i < parts.length; i++) {
			res[i] = Short.parseShort(parts[i]);
		}
		
		return res;
		
	}

}
